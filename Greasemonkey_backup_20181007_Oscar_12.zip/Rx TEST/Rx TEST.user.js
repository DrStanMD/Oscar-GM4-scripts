// ==UserScript==
// @name     Rx TEST
// @version  1
// @include     *oscarRx/*
// @require   http://ajax.googleapis.com/ajax/libs/jquery/1.3/jquery.min.js
// @require http://ajax.googleapis.com/ajax/libs/jquery/1.3.1/jquery.min.js
// @grant    none
// ==/UserScript==



function myfunction(){
  alert("HI")
}

//$('#AutoNumber1').css('background-color', 'yellow');
//alert($('#AutoNumber1').html())
y = ".leftGreyLine > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(1) > td:nth-child(2) > table:nth-child(3) > tbody:nth-child(1) > tr:nth-child(3) > td:nth-child(1) > span:nth-child(1) > input:nth-child(1)"
$(y).css('background-color', 'yellow');
$(y).after("<input type='button' value='Triple Rx' onclick='myfunction()'  >")