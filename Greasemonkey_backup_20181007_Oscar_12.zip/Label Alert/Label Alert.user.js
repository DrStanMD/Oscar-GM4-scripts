// ==UserScript==
// @name        Label Alert
// @namespace   DavidScript
// @description Alerts if there is text in the label box
// @include     */lab/CA/ALL/labDisplay.jsp?segmentID=*
// @require   http://ajax.googleapis.com/ajax/libs/jquery/1.3/jquery.min.js
// @grant		none
// @version     1
// ==/UserScript==

    window.addEventListener("load",function(){
	
  
	var ack  = document.getElementsByTagName('input')[14];
	ack.focus();
	var ack2  = document.getElementsByTagName('input')[25];
	var echart = document.querySelectorAll('input[type="button"][value=" E-Chart "]')[0];
	var echart2 = document.querySelectorAll('input[type="button"][value=" E-Chart "]')[1];
	ack.style.background = 'yellow'; 
	ack2.style.background = 'yellow';
	echart.style.background = 'yellow';
	echart2.style.background = 'yellow';
	ack2.onmouseover = labl;
	ack.onmouseover = labl;
	  $('html').keyup(function (e){
          if (e.keyCode == 220) {
              echart.click();
             }
		  if (e.keyCode == 221) {
              $('#acklabel').focus();
             }
		  if (e.keyCode == 190) {
              window.scrollTo(0,document.body.scrollHeight);
             }
		  if (e.keyCode == 188) {
              document.body.scrollTop = document.documentElement.scrollTop = 0;
             }
        })
     
	var labelBox = document.getElementById('acklabel');
    labelBox.onkeypress = function(e){
    if (!e) e = window.event;
    if (e.keyCode == '13'){
    var lab = document.getElementById('acklabel').value;
	var labButton = document.getElementById('createLabel');
	if (lab !== null&&lab!=="") {
	labButton.click();
	 }
	 ack.click();
    }
  }
	
	function labl() {
	var lab = document.getElementById('acklabel').value;
	var labButton = document.getElementById('createLabel');
	if (lab !== null&&lab!=="") {
	labButton.click();
	 }
	}
	
	
	

}, false);