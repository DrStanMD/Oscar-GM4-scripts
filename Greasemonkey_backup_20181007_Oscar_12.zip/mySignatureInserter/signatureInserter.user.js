// ==UserScript==
// @name           mySignatureInserter
// @namespace      StanScript
// @require   http://ajax.googleapis.com/ajax/libs/jquery/1.3.1/jquery.min.js
// @include        *oscarRx*
// @include        *signature_pad/tabletSignature.jsp*
// @include        *eform/efmformadd_data.jsp?fid*

// ==/UserScript==

function swapFrame(frameId){
  let frameEl = document.getElementById(frameId);
  if (frameEl!=null ) {
    // Create <embed> and copy all attributes
    let embedEl = document.createElement('embed');
    for (var att, i = 0, atts = frameEl.attributes, n = atts.length; i < n; i++){
      att = atts[i];
      embedEl.setAttribute(att.nodeName,att.nodeValue);
    }
    // Perform the actual swap
    frameEl.parentElement.replaceChild(embedEl,frameEl); 
    //alert("GM: swapped iframe for embed.");
  } else { setTimeout(swapFrame, 100, frameId);} // Recursively run until the iframe has loaded
}
swapFrame('lightwindow_overlay')
//alert("3")
swapFrame('ightwindow_iframe');
//alert("2")
swapFrame('signatureFrame');
//alert("1")



var elements = (window.location.pathname.split('/', 2))
firstElement = (elements.slice(1))
vPath = ('https://' + location.host + '/' + firstElement)

var frame = window.frameElement; 
//alert(frame)


// replace myIFrame with your iFrame id
// replace myIFrameElemId with your iFrame's element id
// you can work on document.frames['myIFrame'].document like you are working on
// normal document object in JS
//var ctx = window.frames['signatureFrame'].document.getElementById('canvas').getContext('2d')
//ctx.fillStyle = "blue";
//ctx.fillRect(0, 0, canvas.width, canvas.height);

/*
if(document.getElementById('canvas')){
   alert("OK")
}

else{
location.reload() 
}
*/

setTimeout(function(){ 
if(document.getElementById('canvas').getContext('2d')){
var ctx = document.getElementById('canvas').getContext('2d')
  //alert("Hello")
  base_image = new Image();
  base_image.src = vPath + '/eform/displayImage.do?imagefile=donaldduck.jpg'
  ctx.drawImage(base_image, 0, 0, 500, 100);
  ctx.beginPath();
  ctx.lineWidth = '2';
  ctx.strokeStyle = 'green'; // Green path
  ctx.moveTo(0, 75);
  //Math.floor(Math.random() * (max - min + 1)) + min;
  var rnd = Math.floor(Math.random() * (100 - 40 + 1)) + 40;
  ctx.lineTo(250, rnd);
  ctx.stroke(); // Draw it
  ctx.beginPath();
  ctx.strokeStyle = 'purple'; // Purple path
  var rnd1 = Math.floor(Math.random() * (200 - 0 + 1)) + 0;
  ctx.moveTo(rnd1, 0);
  ctx.lineTo(150, 130);
  ctx.stroke(); // Draw it

}
  }, 1000);

