// ==UserScript==
// @name           SignatureInserter
// @namespace      oscar
// @include        */signature_pad/tabletSignature.jsp?inWindow=true&signatureRequestId=*
// @include        *oscarRx*
// ==/UserScript==

var theContextRoot = document.location.href.replace(document.location.search,'').replace('signature_pad/tabletSignature.jsp','');
var theScratchPadLink=theContextRoot+'scratch/index.jsp';
var theTarget = document.getElementById('signMessage');
var theInsertButton = document.createElement('button');
theInsertButton.innerHTML='Insert';
theInsertButton.onclick = function(){
	var request=new XMLHttpRequest();
	request.open('GET', theScratchPadLink, false);
	request.send();
	if (request.status==200) {
		var theFormStart=request.responseText.indexOf('<form');
		var theTextAreaStart=request.responseText.indexOf('<textarea');
		var theFields=request.responseText.substring(theFormStart,theTextAreaStart);
		var theExpression =/<input[\s\S]*?name="([\s\S]*?)"[\s\S]*?value="([\s\S]*?)"[\s\S]*?>/gim;
		var theMatch;
		var theFormData = new FormData();
		while (theMatch=theExpression.exec(theFields)){
			switch (theMatch[1]) {
			    case "providerNo":
				theFormData.append("providerNo", theMatch[2]);
				break;
			    case "id":
				theFormData.append("id", theMatch[2]);
				break;
			    case "windowId":
				theFormData.append("windowId", theMatch[2]);
				break;
			}			
		}
		theFormData.append("dirty", '1');
		theTextAreaStart=request.responseText.indexOf('>',theTextAreaStart)+1;
		theTextAreaStop=request.responseText.indexOf('</textarea');
		var theTextArea = request.responseText.substring(theTextAreaStart,theTextAreaStop);
		var theSignatureStart=theTextArea.lastIndexOf('***SIGNATURE***');
		if(theSignatureStart>-1){
			var theImage = new Image;
			theImage.onload = function(){
			  document.getElementById('canvas').getContext('2d').drawImage(this,0,0);
			};
			theImage.src = theTextArea.substr(theSignatureStart+15);
			unsafeWindow.OnSignEvent(false, true);
			theSignatureStart=theTextArea.indexOf('***SIGNATURE***');
			theTextArea=theTextArea.substring(0,theSignatureStart);
			theFormData.append("scratchpad", theTextArea);
			var request=new XMLHttpRequest();
			request.open('POST', theContextRoot+'Scratch.do', false);
			request.send(theFormData);			
		}
		else{
			alert('Sorry, no signature found!');
		}
	}
};	
theTarget.parentNode.insertBefore(theInsertButton,theTarget);

