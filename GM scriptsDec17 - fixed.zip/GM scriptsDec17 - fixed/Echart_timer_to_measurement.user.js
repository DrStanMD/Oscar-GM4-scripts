// ==UserScript==
// @name        Echart Timer to measurement 
// @namespace   Stanscripts
// @description   Echart Timer to measurement 
// @include     */casemgmt/forward.jsp?action=view&demographic*
// @include    *oscarEncounter/oscarMeasurements/SetupMeasurements.do*
// @include        *oscarEncounter/GraphMeasurements.do?demographic_no*
// @require http://ajax.googleapis.com/ajax/libs/jquery/1.3/jquery.min.js
// @grant       none
// ==/UserScript==
function setCookie(cname, cvalue, exdays, cpath)
{
  var d = new Date();
  //d.setTime(d.getTime()+(exdays*24*60*60*1000));
  d.setTime(d.getTime() + (exdays * 5000));
  var expires = 'expires=' + d.toGMTString();
  document.cookie = cname + '=' + cvalue + '; ' + expires + '; ' + cpath
}
function getCookie(cname)
{
  var name = cname + '=';
  var ca = document.cookie.split(';');
  for (var i = 0; i < ca.length; i++)
  {
    var c = ca[i].trim();
    if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
  }
  return '';
} //x = $('#enTemplate');
//x.css('background-color', 'yellow');

c = window.location.toString() //setCookie('UNLOAD', 'Date()', 360, 'path=/')
if (c.indexOf('TimeLog') > - 1)
{
  if (getCookie('LOAD') != '') {
    $('input[name=\'value(comments-0)\']').val('LOAD:' + getCookie('LOAD'))
    $('input[name=\'value(inputValue-0)\']').val(0)
    setCookie('START', getCookie('LOAD'), 360, 'path=/') //alert(getCookie('START'))
  }
  if (getCookie('UNLOAD') != '') {
    // alert(getCookie('START'))
    $('input[name=\'value(comments-0)\']').val('UNLOAD:' + getCookie('UNLOAD')) // alert(getCookie('UNLOAD'))
    var startTime = new Date(getCookie('START'))
    var endTime = new Date(getCookie('UNLOAD'))
    var difference = endTime.getTime() - startTime.getTime(); // This will give difference in milliseconds
    var resultInMinutes = Math.round(difference / 60000);
    // $('input[name=\'value(inputValue-0)\']').val(resultInMinutes)
    $('input[name=\'value(inputValue-0)\']').val(difference)
  }
} 
else {
  setCookie('LOAD', '', 360, 'path=/')
  setCookie('UNLOAD', '', 360, 'path=/')
  var myWindow = ''
  var elements = (window.location.pathname.split('/', 2))
  firstElement = (elements.slice(1)) //
  vPath = ('https://' + location.host + '/' + firstElement + '/')
  var myParam = location.search.split('demographicNo=') [1]
  var res = myParam.indexOf('&')
  var demo_no = myParam.substring(0, res)
  window.onbeforeunload = function () {
    showAlert190('UNLOAD')
  }
  window.onload = function () {
    showAlert190('LOAD')
  }
  var input190 = document.createElement('input');
  input190.type = 'button';
  input190.value = 'Time';
  input190.onclick = showAlert190
  input190.setAttribute('style', 'width:70px;font-size:16px;z-index:1;position:fixed;bottom:210px;right:0px');
  document.body.appendChild(input190);
  function showAlert190(myval)
  {
    //alert(myval)
    var formPath = vPath + 'oscarEncounter/oscarMeasurements/SetupMeasurements.do?groupName=TimeLog'
    setCookie(myval, Date(), 360, 'path=/') //alert(getCookie(myval))
    myWindow = window.open(formPath) /*
    setTimeout(function(){ 
    myWindow = window.open(formPath)
     }, 3000);
     */
  }
}
